#ifndef CSV_PARSE_H
#define CSV_PARSE_H

#include "data.h"

#include <iterator>
#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>

// std::string fname1;
// std::vector<std::vector<std::string>> content1;
// std::vector<std::string> row1;
// std::string line1, word1;

void parse(std::string *fileName);

#endif